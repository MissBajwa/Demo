export * from  './Latestproduct'
export * from './Whycard'
export * from './Testimonial'