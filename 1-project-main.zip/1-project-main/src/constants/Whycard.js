
import { card, card1, card2 } from "../components/assets";

export const Whycard= [{
    id:1,
    Images : card2,
    name : 'Fast Delivery',
},
{
    id:1,
    Images : card,
    name : 'Free Shiping',
},
{
    id:1,
    Images : card1,
    name : 'Best Quality',
}
]