export const Testimonials = [{
    name : 'hello'
    
},
{
    name : 'hello'
    
},
 {
    name : 'hello'
    
},

]