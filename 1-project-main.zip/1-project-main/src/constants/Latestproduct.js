import { Bear, Bear1, Bear2, Flower, Flower1, Flower2, FlowerRose, GoldRing, Image, Red, Red1, Red2, Ring, Ring1, Ring2, Ring3, SEIKOwatch, cup, cup1, cup2, cup3, cup4, phone, phone1, phone2, watch, watch1, watch2 } from "../components/assets";

export const Latestproduct= [{
    id : 1,
    Images : Red,
    name : 'PURSE' ,
    design : [Red,Red1,Red2],
    Price : 200
},
{
    id : 2,
    Images :Ring3 ,
    design : [Ring3,Ring2,Ring1],
    name : 'RING' ,
    Price : 4000
},
{
    id : 3,
    Images :FlowerRose  ,
    design : [FlowerRose,Flower1,Flower2],
    name : 'FLOWER' ,
    Price : 500
},
{
    id : 4,
    Images :watch2 ,
    design :[watch,watch1,watch2],
    name : 'WATCH' ,
    Price : 300
},
{
    id : 5,
    Images :Bear ,
    design : [Bear,Bear1,Bear2],
    name : 'BEAR' ,
    Price : 2600
},
{
    id : 6,
    Images :phone ,
    name : 'Infinix ' ,
    Price : 2100,
    design :[phone,phone1,phone2]

},
{
    id : 7,
    Images :cup3 ,
    name : 'RING' ,
    design : [cup3,cup4],
    Price : 2300
},
{
    id : 8,
    Images : cup,
    design : [cup,cup1,cup2],
    name : 'Cremic ',
    Price : 230
}]
