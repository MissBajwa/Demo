import React from 'react'

export const Modals = () => {
  return (
    <div>
       
    </div>
  )
}
