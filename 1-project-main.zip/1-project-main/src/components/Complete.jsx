import React from 'react'

export const Complete = () => {
  return (
    <div>Complete</div>
  )
}
