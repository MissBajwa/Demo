import Home from "./slider-img.png";
import Image from "./purse.png"
import Ring from './ring.png'
import Flower from './flower.png'
import Flower1 from './Bouquet-Of-Imported-Red-Roses-And-Lilies-600x600.webp'
import Flower2 from './WhatsApp-Image-2023-02-10-at-01.38.17.webp'
import watch from './p7584-skeleton-automatic-mens-watch.jpg'
import watch1 from './p7584-skeleton-automatic-mens-watch_1.jpg'
import watch2 from './p7584-skeleton-automatic-mens-watch_2.jpg'
import Bear from './610KLTodI0L._AC_SL1500_.jpg'
import Bear1 from './61d40UpywJL._AC_SL1500_.jpg'
import Bear2 from './61wJWC9YBoL._AC_SL1500_.jpg'
import FlowerRose from './Rose.png'
import GoldRing from './glod.png'
import SEIKOwatch from './Seiko.png'
import Image1 from './saving-img.png'
import card from './free.svg'
import card1 from './high-quality.svg'
import card2 from './truck.svg'
import baloon from './gifts.png'
import map from './images (7).jpeg'
import cup from './cup.jpg'
import cup1 from './cup1.jpg'
import cup2 from './cup2.jpg'
import cup3 from './product-03.jpg'
import cup4 from './product-11-600x671.jpg'
import  Ring3 from './Ring.jpg'
import  Ring1 from './Ring1.jpg'
import  Ring2 from './Ring2.jpg'
import  Red from './IMG_6824.webp'
import  Red1 from './IMG_6825.webp'
import  Red2 from './IMG_6826.webp'
import  phone from './phone.jpg'
import  phone1 from './phone1.jpg'
import  phone2 from './phone2.jpg'



export
{
    Home, Image,Ring,Flower,watch,Bear,FlowerRose,SEIKOwatch,GoldRing ,Image1,card,card1,card2,baloon,map
    ,cup,cup1,cup2,Ring3,Ring1,Ring2,Red,Red1,Red2,watch1,watch2,Bear1,Bear2,cup3,cup4,Flower1,Flower2,phone,phone1,phone2
}
